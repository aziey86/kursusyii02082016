<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\book;

/**
* 
*/
class BookController extends Controller
{
	
	public function actionList()
	{
		return $this->render('list');
	}
}

?>